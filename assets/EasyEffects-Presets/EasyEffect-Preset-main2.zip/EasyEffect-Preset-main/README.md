# OpenEQ
OpenEQ is an Equalizer Settings with 17 bands who give you open sound experience !

To install it drag this file here :

    ~/.config/easyeffects/output/

Drop IRS file here :

    ~/.config/easyeffects/irs/
